package com.wikihacks.module;

public enum Category {

    PLAYER, MOVEMENT, RENDER, MISC, GUI

}
