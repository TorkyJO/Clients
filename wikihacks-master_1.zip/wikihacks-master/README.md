# WikiHacks
```sh
sudo pacman piss
```